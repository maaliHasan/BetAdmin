<!DOCTYPE html>
<html ng-app="app">
<head>
	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.2.23/angular.min.js"></script>
	<script src="https://angular-ui.github.io/bootstrap/ui-bootstrap-tpls-0.12.0.js"></script>
	<link href="https://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" rel="stylesheet">
	<link href="./style.css" rel="stylesheet">
	<script src="./app.js" type="text/javascript"></script>
</head>
<body >
	<div id='container'>
		<header>
			<div id='header-left'>
				<img src='./images/logo.png'/>
			</div>
			<div id='header-content'>
				<Span id='header-title'>Win555B</Span><br/>
				<Span id='header-sub-title'>Administrator</Span>
			</div>
		</header>
		<div ng-controller="PaginationDemoCtrl" id='content'>
			<div class='pagenation'>
				<pagination rotate="false" max-size="20" boundary-links="true" total-items="count" ng-model="currentPage" ng-change="pageChanged()" items-per-page="limit" class="pagination-sm" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
			</div>
			
			<table datatable="ng" class="table">
				<thead>
				<tr>
					<th>ID</th>
					<th>FirstName</th>
					<th>LastName</th>
					<th>email</th>
				</tr>
				</thead>
				<tbody>
				<tr ng-repeat="person in users">
					<td>{{$index+1 + id}}</td>
					<td>{{person.firstname}}</td>
					<td>{{person.lastname}}</td>
					<td>{{person.email}}</td>
				</tr>
				</tbody>
			</table>
			
			<div class='pagenation'>
				<pagination rotate="false" max-size="20" boundary-links="true" total-items="count" ng-model="currentPage" ng-change="pageChanged()" items-per-page="limit" class="pagination-sm" previous-text="&lsaquo;" next-text="&rsaquo;" first-text="&laquo;" last-text="&raquo;"></pagination>
			</div>
			
		</div>
		<footer>Copyright &copy; Win555.com</footer>
	</div>
</body>
</html>