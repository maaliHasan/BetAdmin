angular.module('app', ['ui.bootstrap']);


angular.module('app').controller('PaginationDemoCtrl', function($scope, $http) {
  $scope.currentPage = 1;
  $scope.limit= 50;

  $scope.users = [];
  getData();

	function getData() {
		$http.get("./wrapper.php/?page="+$scope.currentPage+"&length="+$scope.limit)
		.then(function(response) {
			console.log(response.data);
			$scope.id = (response.data.currentPage-1)*$scope.limit;
			$scope.count = response.data.usersCount;
			$scope.users = response.data.users;
			angular.copy(response.data.users.length, $scope.count)
		});
	}

//get another portions of data on page changed
  $scope.pageChanged = function() {
    getData();
  };
});